# import uuid
# from datetime import datetime, timedelta
#
# from django.conf import settings
# from jose import jwt, JWTError
# from jose.constants import ALGORITHMS
#
# from user_service import UserService
#
# class JWTService:
#     JWT_SECRET = settings.JWT["JWT_SECRET"]
#     JWT_EXP_DELTA_DAYS = settings.JWT["JWT_EXP_DELTA_DAYS"]
#
#     @staticmethod
#     def create_token(user_id, phone_number, current_token_version):
#         payload = {'user_id': user_id, 'version': current_token_version,
#                    'exp': datetime.utcnow() + timedelta(days=JWTService.JWT_EXP_DELTA_DAYS)}
#
#         token = jwt.encode(payload, JWTService.JWT_SECRET, ALGORITHMS.HS512)
#
#         return token
#
#     @staticmethod
#     def verify_token(jwt_token):
#         jwt_payload = jwt.decode(jwt_token, JWTService.JWT_SECRET, ALGORITHMS.HS512)
#
#         # The get_user_by_id method returns the user information by user_id, we then retrieves the token_version of
#         # that user and compare it with the token version of the JWT.
#         user_token_version = UserService.get_user_by_id(jwt_payload["user_id"]).token_version
#         if user_token_version != jwt_payload["version"]:
#             raise JWTError("Invalidated JWT token")
#
#         return jwt_payload
